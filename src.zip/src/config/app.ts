import express from "express";
import helmet from "helmet";
import cors from "cors";
import morgan from "morgan";
import dotenv from "dotenv";
import userRoutes from "../routes/user.routes";
import cardRoutes from "../routes/card.routes";
import centeringRoutes from "../routes/centering.routes";
import { supabase } from "../lib/supabase";
import billingRoutes from "../routes/billing.routes";
import syncRoutes from "../routes/sync.routes";
import inventoryRoutes from "../routes/inventory.route";
import portfolioRoutes from "../routes/portfolio.routes";
import variantRoutes from "../routes/variant.route";

dotenv.config();

const app = express();
app.set("trust proxy", 1);

app.use(helmet());
app.use(cors({ origin: process.env.ALLOWED_ORIGINS?.split(",") ?? "*" }));
app.use(express.json({ limit: "10kb" }));
app.use(morgan("combined"));

app.use("/api/v1/users", userRoutes);
app.use("/api/v1/cards", cardRoutes);
app.use("/api/v1/centering", centeringRoutes);
app.use("/api/v1/sync", syncRoutes);
app.use("/api/v1/inventory", inventoryRoutes);
app.use("/api/v1/portfolio", portfolioRoutes);
app.use("/api/v1/variants", variantRoutes);

// Add BEFORE express.json() so the webhook route gets the raw body
app.use(
  "/api/v1/billing/webhook",
  express.raw({ type: "application/json" }),
  (_req, _res, next) => {
    next();
  },
);

// After your other routes:
app.use("/api/v1/billing", billingRoutes);

app.post("/debug/token", async (req, res) => {
  const authHeader = req.headers.authorization;
  const token = authHeader?.split(" ")[1];
  if (!token) return res.json({ error: "no token" });

  const { data, error } = await supabase.auth.getUser(token);
  return res.json({
    user: data?.user?.email,
    role: data?.user?.app_metadata?.role,
    error: error?.message,
  });
});

app.use((_req, res) => {
  res.status(404).json({ error: "Route not found" });
});

export default app;
