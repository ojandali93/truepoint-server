import {
  findInventoryByUser,
  findSoldByUser,
  setInventorySoldStatus,
  findInventoryItemById,
  insertInventoryItem,
  insertInventoryBatch,
  updateInventoryItem,
  deleteInventoryItem,
  fetchCardPrices,
  fetchProductPrices,
  fetchVariantPrices,
  CreateInventoryInput,
  UpdateInventoryInput,
  InventoryRow,
  GradingCompany,
} from "../repositories/inventory.repository";

import {
  fetchSkuPriceRows,
  pickSkuPrice,
  SkuPriceRow,
} from "../repositories/skuPrice.repository";

import { requireFeature } from "./plan.service";

// ─── Types ────────────────────────────────────────────────────────────────────

export interface MarketValue {
  marketPrice: number | null;
  source: string | null;
}

export interface InventoryItemWithValue extends InventoryRow {
  marketValue: MarketValue;
  gainLoss: number | null;
  gainLossPct: number | null;
}

export interface InventorySummary {
  totalItems: number;
  rawCards: number;
  gradedCards: number;
  sealedProducts: number;
  totalCostBasis: number;
  totalMarketValue: number;
  totalGainLoss: number;
  totalGainLossPct: number | null;
}

// Normalize a variant_type into the lookup key used by fetchVariantPrices
// (lowercase, alphanumeric only). "Reverse Holofoil" → "reverseholofoil",
// "reverse_holofoil" → "reverseholofoil" — so the inventory entry and the
// card_variants row match regardless of formatting.
const variantKey = (v: string | null | undefined): string =>
  (v ?? "").toLowerCase().replace(/[^a-z0-9]/g, "");

// ─── Price resolution ─────────────────────────────────────────────────────────

// Determine the best market price for an inventory item.
//
// Resolution priority:
//   1. manual_market_value override (set by user or grader return)
//   2. sealed product → product_price_cache
//   3. raw card → card_variants price (denormalized, source of truth) →
//      representative card price → SKU price → legacy market_prices fallback
//   4. graded card → graded price by company+grade ONLY (no raw fallback —
//      see comment in the graded-card branch below for the reasoning)
const resolveMarketValue = (
  item: InventoryRow,
  cardPrices: Map<string, Record<string, number>>,
  productPrices: Map<string, number>,
  skuPrices: Map<string, SkuPriceRow[]>,
  variantPrices: Map<string, number>,
  variantPricesAny: Map<string, number>,
): MarketValue => {
  // Manual override — takes precedence over all API-sourced prices.
  // Set when (a) a graded card is returned from the grader and the user
  // enters its value, or (b) the user manually edits an inventory item's
  // value. The nightly pricing job is responsible for clearing this once
  // it has real market data.
  if (item.manual_market_value != null) {
    return {
      marketPrice: Number(item.manual_market_value),
      source: item.manual_market_value_source ?? "manual",
    };
  }

  // Sealed product
  if (item.item_type === "sealed_product" && item.product_id) {
    const price = productPrices.get(item.product_id) ?? null;
    return {
      marketPrice: price,
      source: price ? "tcgplayer/cardmarket" : null,
    };
  }

  // Raw card
  if (item.item_type === "raw_card" && item.card_id) {
    // 1) Exact variant price from card_variants (the source of truth).
    //    Keyed on card_id + variant_type — exactly what the scanner stores.
    const exact = variantPrices.get(
      `${item.card_id}|${variantKey(item.variant_type)}`,
    );
    if (exact != null) return { marketPrice: exact, source: "tcgplayer" };

    // 2) The card has a price, but under a different variant (e.g. the scanner
    //    mis-tagged the variant as holofoil). Show the card's representative
    //    price so the value isn't zero. Approximate until the variant is fixed.
    const anyV = variantPricesAny.get(item.card_id);
    if (anyV != null) return { marketPrice: anyV, source: "tcgplayer" };

    // 3) SKU-aware fallback (condition + variant). Dead until the scanner /
    //    sku sync populates tcgapis_sku_id, but kept for when it does.
    const skuRows = skuPrices.get(item.card_id);
    const fromSku = pickSkuPrice(
      skuRows,
      item.variant_type ?? null,
      item.condition ?? null,
    );
    if (fromSku.price != null) {
      return { marketPrice: fromSku.price, source: fromSku.source };
    }

    // 4) Legacy variant-level market_prices fallback.
    const prices = cardPrices.get(item.card_id);
    if (!prices) return { marketPrice: null, source: null };
    if (prices.raw_market)
      return { marketPrice: prices.raw_market, source: "tcgplayer" };
    if (prices.cm_market)
      return { marketPrice: prices.cm_market, source: "cardmarket" };
    return { marketPrice: null, source: null };
  }

  // Graded card — look up graded price for matching company + grade
  if (
    item.item_type === "graded_card" &&
    item.card_id &&
    item.grading_company &&
    item.grade
  ) {
    const prices = cardPrices.get(item.card_id);
    if (!prices) return { marketPrice: null, source: null };

    // Map grading company to source key used in cached_card_prices
    const sourceMap: Record<GradingCompany, string> = {
      PSA: "psa",
      BGS: "bgs",
      CGC: "cgc",
      SGC: "sgc",
      TAG: "tag",
    };

    const sourceKey = sourceMap[item.grading_company];
    const gradeKey = `${sourceKey}_${item.grade}`;

    if (prices[gradeKey]) {
      return { marketPrice: prices[gradeKey], source: item.grading_company };
    }

    // No graded price available.
    //
    // IMPORTANT: do NOT fall back to raw price here. Showing the raw price
    // for a graded card is a lie that compounds into wrong portfolio totals,
    // wrong snapshot values, and wrong gain/loss math. If PokeTrace doesn't
    // have a price for this (card, company, grade) combo, we return null and
    // let the UI display "pending" / "—" instead. The full-catalog graded
    // sync (POST /sync/graded-prices-all, run via daily cron) is responsible
    // for keeping this cache populated.
    return { marketPrice: null, source: null };
  }

  return { marketPrice: null, source: null };
};

// ─── Service functions ────────────────────────────────────────────────────────

export const getInventory = async (
  userId: string,
  collectionId?: string | null,
): Promise<{ items: InventoryItemWithValue[]; summary: InventorySummary }> => {
  const rows = await findInventoryByUser(userId, collectionId);

  if (!rows.length) {
    return {
      items: [],
      summary: {
        totalItems: 0,
        rawCards: 0,
        gradedCards: 0,
        sealedProducts: 0,
        totalCostBasis: 0,
        totalMarketValue: 0,
        totalGainLoss: 0,
        totalGainLossPct: null,
      },
    };
  }

  // Collect all IDs for batch price fetching
  const cardIds = [
    ...new Set(rows.filter((r) => r.card_id).map((r) => r.card_id!)),
  ];

  const productIds = [
    ...new Set(
      rows
        .filter((r) => r.product_id && r.item_type === "sealed_product")
        .map((r) => r.product_id!),
    ),
  ];

  // Fetch all prices in parallel:
  //  - card_variants prices (denormalized NM price per variant — primary source
  //    of truth for raw cards; keyed on card_id + variant_type)
  //  - SKU prices (condition-aware; currently unused until SKUs are populated)
  //  - legacy card prices (market_prices — graded + fallback)
  //  - sealed product prices
  const [skuPrices, cardPrices, productPrices, variantPriceMaps] =
    await Promise.all([
      fetchSkuPriceRows(cardIds),
      fetchCardPrices(cardIds),
      fetchProductPrices(productIds),
      fetchVariantPrices(cardIds),
    ]);

  const { byVariant: variantPrices, byCard: variantPricesAny } =
    variantPriceMaps;

  // Attach market values and calculate gain/loss
  let totalCostBasis = 0;
  let totalMarketValue = 0;
  let rawCards = 0;
  let gradedCards = 0;
  let sealedProducts = 0;

  const items: InventoryItemWithValue[] = rows.map((row) => {
    const marketValue = resolveMarketValue(
      row,
      cardPrices,
      productPrices,
      skuPrices,
      variantPrices,
      variantPricesAny,
    );

    const gainLoss =
      marketValue.marketPrice !== null && row.purchase_price !== null
        ? marketValue.marketPrice - row.purchase_price
        : null;

    const gainLossPct =
      gainLoss !== null && row.purchase_price && row.purchase_price > 0
        ? (gainLoss / row.purchase_price) * 100
        : null;

    const qty = row.quantity ?? 1;
    if (row.purchase_price) totalCostBasis += row.purchase_price * qty;
    if (marketValue.marketPrice)
      totalMarketValue += marketValue.marketPrice * qty;

    if (row.item_type === "raw_card") rawCards += qty;
    else if (row.item_type === "graded_card") gradedCards += qty;
    else if (row.item_type === "sealed_product") sealedProducts += qty;

    return { ...row, marketValue, gainLoss, gainLossPct };
  });

  const totalGainLoss = totalMarketValue - totalCostBasis;
  const totalGainLossPct =
    totalCostBasis > 0 ? (totalGainLoss / totalCostBasis) * 100 : null;

  const summary: InventorySummary = {
    totalItems: rows.reduce((sum, r) => sum + (r.quantity ?? 1), 0),
    rawCards,
    gradedCards,
    sealedProducts,
    totalCostBasis,
    totalMarketValue,
    totalGainLoss,
    totalGainLossPct,
  };

  return { items, summary };
};

export const addInventoryItem = async (
  userId: string,
  input: CreateInventoryInput,
  role: string | null = null,
): Promise<InventoryRow> => {
  // Plan gate — Starter can't add inventory at all; sealed products are Pro-only.
  if (input.itemType === "sealed_product") {
    await requireFeature(userId, "sealed_inventory", role);
  } else {
    await requireFeature(userId, "inventory_tracking", role);
  }

  // Validate required fields per type
  if (input.itemType === "raw_card" && !input.cardId) {
    throw { status: 400, message: "card_id is required for raw cards" };
  }
  if (input.itemType === "graded_card") {
    if (!input.cardId)
      throw { status: 400, message: "card_id is required for graded cards" };
    if (!input.gradingCompany)
      throw {
        status: 400,
        message: "grading_company is required for graded cards",
      };
    if (!input.grade)
      throw { status: 400, message: "grade is required for graded cards" };
  }
  if (input.itemType === "sealed_product" && !input.productId) {
    throw {
      status: 400,
      message: "product_id is required for sealed products",
    };
  }

  // Default is_sealed to true for products
  if (input.itemType === "sealed_product" && input.isSealed === undefined) {
    input.isSealed = true;
  }

  return insertInventoryItem(userId, input);
};

export const editInventoryItem = async (
  id: string,
  userId: string,
  input: UpdateInventoryInput,
): Promise<InventoryRow> => {
  const item = await findInventoryItemById(id);
  if (!item) throw { status: 404, message: "Inventory item not found" };
  if (item.user_id !== userId) throw { status: 403, message: "Access denied" };

  return updateInventoryItem(id, userId, input);
};

export const removeInventoryItem = async (
  id: string,
  userId: string,
): Promise<void> => {
  const item = await findInventoryItemById(id);
  if (!item) throw { status: 404, message: "Inventory item not found" };
  if (item.user_id !== userId) throw { status: 403, message: "Access denied" };

  await deleteInventoryItem(id, userId);
};

// ─── Open sealed product ──────────────────────────────────────────────────────

export interface PulledCard {
  cardId: string;
  purchasePrice?: number | null;
  notes?: string | null;
}

export const openSealedProduct = async (
  id: string,
  userId: string,
  pulledCards: PulledCard[],
  role: string | null = null,
): Promise<{ inserted: number }> => {
  await requireFeature(userId, "pack_opening", role);

  const item = await findInventoryItemById(id);
  if (!item) throw { status: 404, message: "Inventory item not found" };
  if (item.user_id !== userId) throw { status: 403, message: "Access denied" };
  if (item.item_type !== "sealed_product") {
    throw { status: 400, message: "Item is not a sealed product" };
  }
  if (!item.is_sealed) {
    throw { status: 400, message: "Product has already been opened" };
  }

  if (!pulledCards.length) {
    throw {
      status: 400,
      message: "At least one pulled card is required to open a product",
    };
  }

  // Validate all card IDs exist
  const { supabaseAdmin } = await import("../lib/supabase");
  const cardIds = pulledCards.map((c) => c.cardId);
  const { data: cards, error } = await supabaseAdmin
    .from("cards")
    .select("id")
    .in("id", cardIds);

  if (error) throw error;
  const foundIds = new Set((cards ?? []).map((c) => c.id));
  const missing = cardIds.filter((id) => !foundIds.has(id));
  if (missing.length) {
    throw { status: 400, message: `Unknown card IDs: ${missing.join(", ")}` };
  }

  // Insert pulled cards as raw inventory items
  const newItems: CreateInventoryInput[] = pulledCards.map((c) => ({
    itemType: "raw_card" as const,
    cardId: c.cardId,
    purchasePrice: c.purchasePrice ?? null,
    notes: c.notes ?? null,
  }));

  await insertInventoryBatch(userId, newItems);

  // Delete the sealed product from inventory
  await deleteInventoryItem(id, userId);

  return { inserted: pulledCards.length };
};

// ─── Portfolio snapshot helper ────────────────────────────────────────────────
// Called by the portfolio cron to record today's total value

export const getCurrentTotalValue = async (
  userId: string,
  collectionId?: string | null,
): Promise<number> => {
  const { summary } = await getInventory(userId, collectionId);
  return summary.totalMarketValue;
};

// ─── Sold tracking ────────────────────────────────────────────────────────────

export interface MarkSoldInput {
  soldPrice: number; // total amount received for this line
  soldPlatform?: string | null; // eBay, TCGPlayer, In person, etc.
  soldAt?: string | null; // ISO date; defaults to now
  soldNotes?: string | null;
}

// Mark an active inventory item as sold.
export const markItemSold = async (
  id: string,
  userId: string,
  input: MarkSoldInput,
): Promise<InventoryRow> => {
  const item = await findInventoryItemById(id);
  if (!item) throw { status: 404, message: "Inventory item not found" };
  if (item.user_id !== userId) throw { status: 403, message: "Access denied" };
  if (item.status === "sold")
    throw { status: 400, message: "Item is already marked sold" };
  if (input.soldPrice === undefined || input.soldPrice === null)
    throw { status: 400, message: "soldPrice is required" };

  return setInventorySoldStatus(id, userId, {
    status: "sold",
    sold_price: Number(input.soldPrice),
    sold_platform: input.soldPlatform ?? null,
    sold_at: input.soldAt ?? new Date().toISOString(),
    sold_notes: input.soldNotes ?? null,
  });
};

// Revert a sale — item returns to active inventory, sale fields cleared.
export const revertItemSold = async (
  id: string,
  userId: string,
): Promise<InventoryRow> => {
  const item = await findInventoryItemById(id);
  if (!item) throw { status: 404, message: "Inventory item not found" };
  if (item.user_id !== userId) throw { status: 403, message: "Access denied" };

  return setInventorySoldStatus(id, userId, {
    status: "active",
    sold_price: null,
    sold_platform: null,
    sold_at: null,
    sold_notes: null,
  });
};

export interface SoldItem extends InventoryRow {
  costBasis: number; // (purchase_price ?? 0) * quantity
  proceeds: number; // sold_price
  profit: number; // proceeds - costBasis
  profitPct: number | null;
}

export interface SoldSummary {
  count: number;
  totalCostBasis: number;
  totalProceeds: number;
  totalProfit: number;
  totalProfitPct: number | null;
}

// All sold items with per-item + aggregate realized profit.
export const getSoldItems = async (
  userId: string,
): Promise<{ items: SoldItem[]; summary: SoldSummary }> => {
  const rows = await findSoldByUser(userId);

  let totalCostBasis = 0;
  let totalProceeds = 0;

  const items: SoldItem[] = rows.map((row) => {
    const qty = row.quantity ?? 1;
    const costBasis = (row.purchase_price ?? 0) * qty;
    const proceeds = row.sold_price ?? 0;
    const profit = proceeds - costBasis;
    const profitPct = costBasis > 0 ? (profit / costBasis) * 100 : null;

    totalCostBasis += costBasis;
    totalProceeds += proceeds;

    return { ...row, costBasis, proceeds, profit, profitPct };
  });

  const totalProfit = totalProceeds - totalCostBasis;
  const totalProfitPct =
    totalCostBasis > 0 ? (totalProfit / totalCostBasis) * 100 : null;

  return {
    items,
    summary: {
      count: rows.length,
      totalCostBasis,
      totalProceeds,
      totalProfit,
      totalProfitPct,
    },
  };
};
