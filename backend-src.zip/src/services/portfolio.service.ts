import {
  findSnapshotsByUser,
  upsertSnapshot,
  findAllUsersWithInventory,
} from "../repositories/portfolio.repository";
import { getCollections } from "./collection.service";
import { getInventory } from "./inventory.service";
import { requireFeature } from "./plan.service";

// ─── Types ────────────────────────────────────────────────────────────────────

/** Response shape for GET portfolio (live + snapshot history). */
export interface PortfolioData {
  userId: string;
  collectionId: string | null;
  totalValue: number;
  totalCostBasis: number;
  totalGainLoss: number;
  totalGainLossPct: number | null;
  rawCardValue: number;
  gradedCardValue: number;
  sealedProductValue: number;
  rawCards: number;
  gradedCards: number;
  sealedProducts: number;
  history: {
    date: string;
    totalValue: number;
    costBasis: number;
    gainLoss: number;
    rawCardValue: number;
    gradedCardValue: number;
    sealedProductValue: number;
  }[];
  allTimeHigh: number;
  allTimeLow: number;
  changeToday: number | null;
  changeTodayPct: number | null;
  change7d: number | null;
  change7dPct: number | null;
  change30d: number | null;
  change30dPct: number | null;
  topGainers: TopPerformer[];
  topLosers: TopPerformer[];
  totalItems: number;
  lastSnapshotDate: string | null;
  hasHistory: boolean;
}

export interface TopPerformer {
  id: string;
  name: string;
  setName: string;
  imageUrl: string | null;
  itemType: string;
  gradingCompany: string | null;
  grade: string | null;
  purchasePrice: number | null;
  marketPrice: number | null;
  gainLoss: number | null;
  gainLossPct: number | null;
}

// ─── Snapshot creation ────────────────────────────────────────────────────────

const writeSnapshot = async (
  userId: string,
  collectionId: string | null,
): Promise<void> => {
  const { items, summary } = await getInventory(userId, collectionId);

  let rawCardValue = 0;
  let gradedCardValue = 0;
  let sealedProductValue = 0;
  for (const item of items) {
    const v = item.marketValue.marketPrice ?? 0;
    if (item.item_type === "raw_card") rawCardValue += v;
    else if (item.item_type === "graded_card") gradedCardValue += v;
    else if (item.item_type === "sealed_product") sealedProductValue += v;
  }

  await upsertSnapshot({
    userId,
    collectionId, // null = aggregate (all collections), or a specific collection
    snapshotDate: new Date().toISOString().split("T")[0],
    totalValue: summary.totalMarketValue,
    totalCostBasis: summary.totalCostBasis,
    totalGainLoss: summary.totalGainLoss,
    rawCardValue,
    gradedCardValue,
    sealedProductValue,
    totalItems: summary.totalItems,
    rawCards: summary.rawCards,
    gradedCards: summary.gradedCards,
    sealedProducts: summary.sealedProducts,
  });
};

export const createSnapshotForUser = async (
  userId: string,
): Promise<{ collections: number; aggregate: boolean }> => {
  // 1) Aggregate snapshot — ALL collections combined (collection_id = NULL).
  //    getInventory(userId, null) returns every item across all collections.
  await writeSnapshot(userId, null);

  // 2) One snapshot per collection.
  let collectionCount = 0;
  try {
    const collections = await getCollections(userId);
    for (const c of collections) {
      try {
        await writeSnapshot(userId, c.id);
        collectionCount++;
      } catch (err: any) {
        // One bad collection shouldn't kill the rest or the aggregate.
        console.error(
          `[Portfolio] Snapshot failed for user ${userId} collection ${c.id}:`,
          err?.message,
        );
      }
    }
  } catch (err: any) {
    console.error(
      `[Portfolio] Could not list collections for user ${userId}:`,
      err?.message,
    );
  }

  return { collections: collectionCount, aggregate: true };
};

// ─── Full portfolio sync — called by cron ─────────────────────────────────────

export const syncAllPortfolios = async (): Promise<{
  total: number;
  succeeded: number;
  failed: number;
}> => {
  const userIds = await findAllUsersWithInventory();

  let succeeded = 0;
  let failed = 0;

  for (const userId of userIds) {
    try {
      await createSnapshotForUser(userId);
      succeeded++;
    } catch {
      failed++;
    }
    // Small delay to avoid hammering the DB
    await new Promise((res) => setTimeout(res, 200));
  }

  console.log(
    `[Portfolio] Sync complete. Succeeded: ${succeeded}, Failed: ${failed}`,
  );
  return { total: userIds.length, succeeded, failed };
};

// ─── Portfolio analytics for a single user ────────────────────────────────────

export const getPortfolio = async (
  userId: string,
  days = 30,
  collectionId?: string | null,
  role: string | null = null,
): Promise<PortfolioData> => {
  await requireFeature(userId, "portfolio_dashboard", role);

  // Run inventory fetch and history fetch in parallel
  const [inventoryData, snapshots] = await Promise.all([
    getInventory(userId, collectionId),
    findSnapshotsByUser(userId, days, collectionId),
  ]);

  const { items, summary } = inventoryData;

  // Today's snapshot may not exist yet — use live inventory data as current
  const currentValue = summary.totalMarketValue;
  const costBasis = summary.totalCostBasis;
  const gainLoss = summary.totalGainLoss;
  const gainLossPct = costBasis > 0 ? (gainLoss / costBasis) * 100 : null;

  // Breakdown by type (live)
  let rawCardValue = 0;
  let gradedCardValue = 0;
  let sealedProductValue = 0;

  for (const item of items) {
    const v = item.marketValue.marketPrice ?? 0;
    if (item.item_type === "raw_card") rawCardValue += v;
    else if (item.item_type === "graded_card") gradedCardValue += v;
    else if (item.item_type === "sealed_product") sealedProductValue += v;
  }

  // Build history array from snapshots
  // Inject today's live value as the last point
  const today = new Date().toISOString().split("T")[0];
  const historyFromSnapshots = snapshots.map((s) => ({
    date: s.snapshotDate,
    totalValue: s.totalValue,
    costBasis: s.totalCostBasis,
    gainLoss: s.totalGainLoss,
    rawCardValue: s.rawCardValue,
    gradedCardValue: s.gradedCardValue,
    sealedProductValue: s.sealedProductValue,
  }));

  // Replace or append today's live data
  const hasToday = historyFromSnapshots.some((h) => h.date === today);
  if (!hasToday && currentValue > 0) {
    historyFromSnapshots.push({
      date: today,
      totalValue: currentValue,
      costBasis,
      gainLoss,
      rawCardValue,
      gradedCardValue,
      sealedProductValue,
    });
  }

  // Performance metrics
  const allValues = historyFromSnapshots.map((h) => h.totalValue);
  const allTimeHigh =
    allValues.length > 0 ? Math.max(...allValues) : currentValue;
  const allTimeLow =
    allValues.length > 0 ? Math.min(...allValues) : currentValue;

  const findValueDaysAgo = (d: number): number | null => {
    const target = new Date();
    target.setDate(target.getDate() - d);
    const targetDate = target.toISOString().split("T")[0];
    // Find closest snapshot at or before that date
    const candidates = historyFromSnapshots.filter((h) => h.date <= targetDate);
    if (!candidates.length) return null;
    return candidates[candidates.length - 1].totalValue;
  };

  const prev1d = findValueDaysAgo(1);
  const prev7d = findValueDaysAgo(7);
  const prev30d = findValueDaysAgo(30);

  const calcChange = (prev: number | null) => {
    if (prev === null) return { change: null, pct: null };
    const change = currentValue - prev;
    const pct = prev > 0 ? (change / prev) * 100 : null;
    return { change, pct };
  };

  const { change: changeToday, pct: changeTodayPct } = calcChange(prev1d);
  const { change: change7d, pct: change7dPct } = calcChange(prev7d);
  const { change: change30d, pct: change30dPct } = calcChange(prev30d);

  // Top performers — items with purchase price and market price
  const itemsWithGainLoss = items
    .filter((item) => item.gainLoss !== null && item.purchase_price !== null)
    .map(
      (item): TopPerformer => ({
        id: item.id,
        name: item.card?.name ?? item.product?.name ?? "Unknown",
        setName: item.card?.sets?.name ?? item.product?.set_id ?? "",
        imageUrl: item.card?.image_small ?? item.product?.image_url ?? null,
        itemType: item.item_type,
        gradingCompany: item.grading_company,
        grade: item.grade,
        purchasePrice: item.purchase_price,
        marketPrice: item.marketValue.marketPrice,
        gainLoss: item.gainLoss,
        gainLossPct: item.gainLossPct,
      }),
    );

  const topGainers = [...itemsWithGainLoss]
    .filter((i) => (i.gainLoss ?? 0) > 0)
    .sort((a, b) => (b.gainLossPct ?? 0) - (a.gainLossPct ?? 0))
    .slice(0, 5);

  const topLosers = [...itemsWithGainLoss]
    .filter((i) => (i.gainLoss ?? 0) < 0)
    .sort((a, b) => (a.gainLossPct ?? 0) - (b.gainLossPct ?? 0))
    .slice(0, 5);

  const latestSnapshot =
    snapshots.length > 0 ? snapshots[snapshots.length - 1] : null;

  return {
    userId,
    collectionId: collectionId ?? null,
    totalValue: currentValue,
    totalCostBasis: costBasis,
    totalGainLoss: gainLoss,
    totalGainLossPct: gainLossPct,
    rawCardValue,
    gradedCardValue,
    sealedProductValue,
    rawCards: summary.rawCards,
    gradedCards: summary.gradedCards,
    sealedProducts: summary.sealedProducts,
    history: historyFromSnapshots,
    allTimeHigh,
    allTimeLow,
    changeToday,
    changeTodayPct,
    change7d,
    change7dPct,
    change30d,
    change30dPct,
    topGainers,
    topLosers,
    totalItems: summary.totalItems,
    lastSnapshotDate: latestSnapshot?.snapshotDate ?? null,
    hasHistory: snapshots.length > 1,
  };
};
